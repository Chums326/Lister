﻿namespace ChumsLister.Core.Models
{
    public class SimilarListing
    {
        public string Title { get; set; }
        public string Price { get; set; }
        public string Platform { get; set; }
    }
}