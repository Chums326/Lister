﻿namespace ChumsLister.Core.Models
{
    public class PlatformFee
    {
        public string Platform { get; set; }
        public string Fee { get; set; }
        public string NetAmount { get; set; }
    }
}