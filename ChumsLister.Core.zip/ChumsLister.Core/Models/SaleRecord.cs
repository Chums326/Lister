﻿namespace ChumsLister.Core.Models
{
    public class SaleRecord
    {
        public string Title { get; set; }
        public decimal TotalPrice { get; set; }
        public DateTime SaleDate { get; set; }
    }
}
