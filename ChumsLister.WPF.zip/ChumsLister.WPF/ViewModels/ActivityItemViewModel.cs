﻿namespace ChumsLister.WPF.ViewModels
{
    public class ActivityItemViewModel
    {
        public string Title { get; set; }
        public string Subtitle { get; set; }
    }
}